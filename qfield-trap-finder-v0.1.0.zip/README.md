# Trap Finder for QField — v0.1.0

Separate seasonal plugin for the CharlesRayNix northern bobwhite project.

## Data source
Reads the QGIS/QField layer named `Bait and Trap Sites`.

Current 2026 trap-site schema confirmed from the refreshed export:
- `Bait_Site_ID`
- `Quadrant`
- `Latitude`
- `Longitude`
- `Elevation`
- `Description`
- `Date_and_Time_Created`
- `Trap_Status`
- `Has_Site_Been_Removed_?`

The plugin deliberately ignores `fid` for identifying a trap site. It treats
`Bait_Site_ID` as the site identifier and only indexes 1000-series sites
(1000–1999).

The supplied Oct. 5 export contains 96 consecutive trap sites, 1001–1096.

## v0.1.0
- Separate install from Bird Finder.
- Search directly by trap-site number.
- Browse all 1000-series trap sites.
- Browse filtering by site ID, quadrant, status, or description.
- Closest active (not removed) trap site using phone GNSS.
- Field Queue: active trap sites sorted nearest-first.
- Displays quadrant, trap status, removed status, coordinates, created date,
  and description/name when present.
- GO TO centers the map on the site.
- NAVIGATE uses QField navigation and the same long-arrow field guide style as
  Bird Finder.
- Live distance, bearing, GPS horizontal accuracy, and phone/movement heading.
- FIT YOU + SITE plus 500/200/100/50/25/10 m map views.
- SHOW ME + SITE.
- COPY COORDS and COPY INFO.
- REFRESH SITE LIST so newly synced cloud sites can be picked up without
  reinstalling the plugin.
- Read-only: does not edit the shared `Bait and Trap Sites` layer.

## Test
After installing, open Trap Finder and confirm it reports 96 sites. Test:
1. Find `1001`.
2. Browse All Trap Sites.
3. Turn on GPS and try Closest Site.
4. Navigate to a known nearby site and verify the arrow/distance.
