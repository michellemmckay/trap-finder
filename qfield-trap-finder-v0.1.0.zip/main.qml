import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield
import org.qgis
import Theme

Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var mapCanvas: iface.mapCanvas()
  property var positioning: iface.positioning()
  property var geometryHighlighter: iface.findItemByObjectName("geometryHighlighter")
  property var navigation: iface.findItemByObjectName("navigation")

  property var siteCatalog: []
  property var filteredSites: []
  property var fieldQueueRows: []
  property var siteIterator: null
  property bool scanActive: false
  property int scanCount: 0
  property bool catalogReady: false
  property string pendingAction: ""

  property string selectedSiteId: ""
  property string selectedQuadrant: "—"
  property string selectedStatus: "—"
  property string selectedRemoved: "—"
  property string selectedDescription: ""
  property string selectedCreated: "—"
  property double selectedLat: NaN
  property double selectedLon: NaN
  property int selectedFid: -1

  property string liveDistance: "—"
  property string liveBearing: "—"
  property string liveAccuracy: "—"
  property real pointerRotation: 0
  property bool pointerValid: false
  property string headingSource: "—"
  property bool navigationGuideHidden: false
  property string statusText: "Loading trap sites…"

  readonly property var viewOptions: ["FIT YOU + SITE", "500 m", "200 m", "100 m", "50 m", "25 m", "10 m"]

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(openButton)
  }

  QfToolButton {
    id: openButton
    iconSource: "icon.svg"
    iconColor: Theme.mainColor
    bgcolor: Theme.darkGray
    round: true
    onClicked: {
      trapDialog.open()
      refreshLiveGuidance()
      if (!catalogReady && !scanActive) startSiteScan("")
    }
  }

  Timer {
    id: siteScanTimer
    interval: 1
    repeat: true
    running: false

    onTriggered: {
      if (!plugin.scanActive || !plugin.siteIterator) {
        stop()
        return
      }

      let processed = 0
      const chunkSize = 100

      while (processed < chunkSize && plugin.siteIterator.hasNext()) {
        const f = plugin.siteIterator.next()
        processed++
        plugin.scanCount++

        try {
          const r = plugin.recordFromFeature(f)
          if (!r.siteId.length) continue
          const n = Number(r.siteId)
          // Trap sites for this project are the 1000-series records.
          if (isNaN(n) || n < 1000 || n >= 2000) continue
          if (isNaN(r.lat) || isNaN(r.lon)) continue
          plugin.siteCatalog.push(r)
        } catch (e) {
          console.warn("Trap Finder: feature read failed:", e)
        }
      }

      plugin.statusText = "Loading trap sites… " + plugin.scanCount + " features checked"

      if (!plugin.siteIterator.hasNext()) {
        plugin.finishSiteScan()
      }
    }
  }

  Timer {
    interval: 500
    repeat: true
    running: trapDialog.visible || (navigation && navigation.isActive)
    onTriggered: refreshLiveGuidance()
  }

  function trapLayer() {
    let layers = qgisProject.mapLayersByName("Bait and Trap Sites")
    if (layers && layers.length > 0) return layers[0]

    layers = qgisProject.mapLayersByName("Bait & Trap Sites")
    if (layers && layers.length > 0) return layers[0]

    mainWindow.displayToast("Bait and Trap Sites layer not found")
    return null
  }

  function firstAttribute(feature, names) {
    for (let i = 0; i < names.length; i++) {
      const v = feature.attribute(names[i])
      if (v !== undefined && v !== null && !FeatureUtils.attributeIsNull(v)) {
        const s = String(v).trim()
        if (s.length > 0 && s !== "undefined" && s !== "null") return v
      }
    }
    return null
  }

  function normalizeId(v) {
    if (v === undefined || v === null) return ""
    let s = String(v).trim()
    if (!s.length || s === "undefined" || s === "null") return ""
    const n = Number(s)
    if (!isNaN(n) && Math.floor(n) === n) return String(n)
    return s
  }

  function recordFromFeature(feature) {
    const site = firstAttribute(feature, [
      "Bait_Site_ID", "Bait Site ID", "BaitSiteID", "Trap_Site_ID",
      "Trap Site ID", "Site_ID", "Site ID"
    ])
    const quadrant = firstAttribute(feature, ["Quadrant", "quadrant"])
    const lat = firstAttribute(feature, ["Latitude", "latitude", "Lat"])
    const lon = firstAttribute(feature, ["Longitude", "longitude", "Lon", "Long"])
    const description = firstAttribute(feature, ["Description", "description", "Site_Name", "Site Name", "Name"])
    const created = firstAttribute(feature, [
      "Date_and_Time_Created", "Date and Time Created", "Created", "Date_Created"
    ])
    const status = firstAttribute(feature, ["Trap_Status", "Trap Status", "Status", "status"])
    const removed = firstAttribute(feature, [
      "Has_Site_Been_Removed_?", "Has Site Been Removed?", "Removed", "removed"
    ])

    return {
      "fid": Number(feature.id),
      "siteId": normalizeId(site),
      "quadrant": quadrant === null ? "—" : String(quadrant),
      "status": status === null ? "—" : String(status),
      "removed": removed === null ? "—" : String(removed),
      "description": description === null ? "" : String(description),
      "created": created === null ? "—" : String(created),
      "lat": lat === null ? NaN : Number(lat),
      "lon": lon === null ? NaN : Number(lon)
    }
  }

  function startSiteScan(action) {
    if (scanActive) return
    const layer = trapLayer()
    if (!layer) return

    siteCatalog = []
    filteredSites = []
    fieldQueueRows = []
    scanCount = 0
    catalogReady = false
    pendingAction = action ? String(action) : ""
    scanActive = true
    statusText = "Loading trap sites…"

    siteIterator = LayerUtils.createFeatureIterator(layer)
    siteScanTimer.start()
  }

  function finishSiteScan() {
    siteScanTimer.stop()
    scanActive = false

    siteCatalog.sort(function(a, b) {
      return Number(a.siteId) - Number(b.siteId)
    })

    filteredSites = siteCatalog.slice()
    catalogReady = true
    statusText = "Indexed " + siteCatalog.length + " trap sites"

    if (pendingAction === "browse") {
      pendingAction = ""
      openSiteList()
    } else if (pendingAction === "closest") {
      pendingAction = ""
      loadClosestSite()
    } else if (pendingAction === "queue") {
      pendingAction = ""
      openFieldQueue()
    }

    if (siteCatalog.length === 0) {
      mainWindow.displayToast("No 1000-series trap sites found")
    } else {
      mainWindow.displayToast("Trap Finder: " + siteCatalog.length + " sites loaded")
    }
  }

  function refreshSites() {
    clearSelection()
    startSiteScan("")
  }

  function isRemoved(record) {
    const s = String(record.removed).trim().toLowerCase()
    return s === "yes" || s === "true" || s === "1" || s === "removed"
  }

  function displayName(record) {
    let s = "Site " + record.siteId
    if (record.description && String(record.description).trim().length) {
      s += " — " + String(record.description).trim()
    }
    return s
  }

  function siteListLabel(record) {
    let s = displayName(record) + "\nQuadrant " + record.quadrant + "   •   " + record.status
    if (isRemoved(record)) s += "   •   REMOVED"

    const info = currentGpsInfo()
    if (info) {
      const d = haversineMeters(Number(info.latitude), Number(info.longitude), record.lat, record.lon)
      s += "   •   " + distanceText(d)
    }
    return s
  }

  function filterSiteList(text) {
    const q = String(text).trim().toLowerCase()
    if (!q.length) {
      filteredSites = siteCatalog.slice()
      return
    }

    filteredSites = siteCatalog.filter(function(r) {
      return String(r.siteId).toLowerCase().indexOf(q) >= 0 ||
             String(r.quadrant).toLowerCase().indexOf(q) >= 0 ||
             String(r.status).toLowerCase().indexOf(q) >= 0 ||
             String(r.description).toLowerCase().indexOf(q) >= 0
    })
  }

  function openSiteList() {
    if (!catalogReady) {
      if (!scanActive) startSiteScan("browse")
      return
    }
    siteFilterField.text = ""
    filterSiteList("")
    siteListDialog.open()
  }

  function findSite(query) {
    const q = String(query).trim().toLowerCase()
    if (!q.length) {
      mainWindow.displayToast("Enter a trap site number")
      return
    }

    if (!catalogReady) {
      pendingAction = ""
      if (!scanActive) startSiteScan("")
      mainWindow.displayToast("Loading trap sites… try again when loaded")
      return
    }

    let matches = siteCatalog.filter(function(r) {
      return String(r.siteId).toLowerCase() === q ||
             String(r.description).toLowerCase().indexOf(q) >= 0
    })

    if (matches.length === 1) {
      selectSite(matches[0])
      return
    }

    if (matches.length > 1) {
      filteredSites = matches
      siteFilterField.text = query
      siteListDialog.open()
      return
    }

    mainWindow.displayToast("Trap site " + query + " not found")
  }

  function chooseSiteFromList(record) {
    siteListDialog.close()
    selectSite(record)
  }

  function selectSite(record) {
    selectedSiteId = String(record.siteId)
    selectedQuadrant = String(record.quadrant)
    selectedStatus = String(record.status)
    selectedRemoved = String(record.removed)
    selectedDescription = String(record.description)
    selectedCreated = String(record.created)
    selectedLat = Number(record.lat)
    selectedLon = Number(record.lon)
    selectedFid = Number(record.fid)
    siteField.text = selectedSiteId
    highlightTarget()
    refreshLiveGuidance()
  }

  function clearSelection() {
    selectedSiteId = ""
    selectedQuadrant = "—"
    selectedStatus = "—"
    selectedRemoved = "—"
    selectedDescription = ""
    selectedCreated = "—"
    selectedLat = NaN
    selectedLon = NaN
    selectedFid = -1
    liveDistance = "—"
    liveBearing = "—"
    liveAccuracy = "—"
    pointerValid = false
    pointerRotation = 0
  }

  function currentGpsInfo() {
    if (!positioning || !positioning.active) return null
    const info = positioning.positionInformation
    if (!info || !info.latitudeValid || !info.longitudeValid) return null
    return info
  }

  function activeSitesWithDistance() {
    const info = currentGpsInfo()
    if (!info) return []

    const lat = Number(info.latitude)
    const lon = Number(info.longitude)

    return siteCatalog.filter(function(r) {
      return !isRemoved(r)
    }).map(function(r) {
      return {
        "siteId": r.siteId,
        "quadrant": r.quadrant,
        "status": r.status,
        "removed": r.removed,
        "description": r.description,
        "created": r.created,
        "lat": r.lat,
        "lon": r.lon,
        "fid": r.fid,
        "distance": haversineMeters(lat, lon, r.lat, r.lon)
      }
    })
  }

  function loadClosestSite() {
    if (!catalogReady) {
      if (!scanActive) startSiteScan("closest")
      else pendingAction = "closest"
      return
    }

    if (!currentGpsInfo()) {
      mainWindow.displayToast("Turn on GPS to find the closest trap site")
      return
    }

    const rows = activeSitesWithDistance()
    if (!rows.length) {
      mainWindow.displayToast("No active trap sites found")
      return
    }

    rows.sort(function(a, b) { return a.distance - b.distance })
    const r = rows[0]
    mainWindow.displayToast("Closest: site " + r.siteId + " • " + distanceText(r.distance))
    selectSite(r)
  }

  function buildFieldQueue() {
    if (!currentGpsInfo()) {
      fieldQueueRows = []
      return
    }

    let rows = activeSitesWithDistance()
    rows.sort(function(a, b) { return a.distance - b.distance })
    fieldQueueRows = rows
  }

  function openFieldQueue() {
    if (!catalogReady) {
      if (!scanActive) startSiteScan("queue")
      else pendingAction = "queue"
      return
    }

    if (!currentGpsInfo()) {
      mainWindow.displayToast("Turn on GPS to sort sites by distance")
      return
    }

    buildFieldQueue()
    fieldQueueDialog.open()
  }

  function queueLabel(record) {
    let s = "Site " + record.siteId + "   •   " + distanceText(record.distance)
    s += "\nQ" + record.quadrant + "   •   " + record.status
    if (record.description && String(record.description).trim().length) {
      s += "   •   " + String(record.description).trim()
    }
    return s
  }

  function chooseQueueSite(record) {
    fieldQueueDialog.close()
    selectSite(record)
  }

  function targetPointWgs84() {
    if (isNaN(selectedLon) || isNaN(selectedLat)) return null
    return GeometryUtils.point(selectedLon, selectedLat)
  }

  function targetPointProjectCrs() {
    const p = targetPointWgs84()
    if (!p) return null
    return GeometryUtils.reprojectPoint(
      p,
      CoordinateReferenceSystemUtils.wgs84Crs(),
      mapCanvas.mapSettings.destinationCrs
    )
  }

  function highlightTarget() {
    if (!geometryHighlighter || isNaN(selectedLon) || isNaN(selectedLat)) return
    const geom = GeometryUtils.createGeometryFromWkt(
      "POINT(" + selectedLon + " " + selectedLat + ")"
    )
    geometryHighlighter.geometryWrapper.qgsGeometry = geom
    geometryHighlighter.geometryWrapper.crs = CoordinateReferenceSystemUtils.wgs84Crs()
  }

  function goToSite() {
    const p = targetPointProjectCrs()
    if (!p) return
    mapCanvas.mapSettings.setCenter(p, true)
    highlightTarget()
    trapDialog.close()
  }

  function navigateToSite() {
    const p = targetPointProjectCrs()
    if (!p) return

    if (!navigation) {
      mainWindow.displayToast("QField navigation object not available")
      return
    }

    navigation.destination = p
    navigationGuideHidden = false
    highlightTarget()
    fitYouAndSite(true)
    trapDialog.close()
    mainWindow.displayToast("Navigating to trap site " + selectedSiteId)
  }

  function fitYouAndSite(showMe) {
    if (isNaN(selectedLat) || isNaN(selectedLon)) return

    const info = currentGpsInfo()
    if (!info) {
      setTargetViewMeters(500)
      mainWindow.displayToast("GPS unavailable; centered on trap site")
      return
    }

    const myLat = Number(info.latitude)
    const myLon = Number(info.longitude)
    const d = haversineMeters(myLat, myLon, selectedLat, selectedLon)

    const padMeters = Math.max(40, d * 0.30)
    const midLat = (myLat + selectedLat) / 2.0
    const cosLat = Math.max(0.15, Math.cos(midLat * Math.PI / 180.0))
    const latPad = padMeters / 111320.0
    const lonPad = padMeters / (111320.0 * cosLat)

    const minLat = Math.min(myLat, selectedLat) - latPad
    const maxLat = Math.max(myLat, selectedLat) + latPad
    const minLon = Math.min(myLon, selectedLon) - lonPad
    const maxLon = Math.max(myLon, selectedLon) + lonPad

    const p1 = GeometryUtils.point(minLon, minLat)
    const p2 = GeometryUtils.point(maxLon, maxLat)
    const rect = GeometryUtils.createRectangleFromPoints(p1, p2)
    const projected = GeometryUtils.reprojectRectangle(
      rect,
      CoordinateReferenceSystemUtils.wgs84Crs(),
      mapCanvas.mapSettings.destinationCrs
    )

    mapCanvas.mapSettings.setExtent(projected, true)
    if (showMe === true) highlightMyLocation()
  }

  function highlightMyLocation() {
    const info = currentGpsInfo()
    if (!info || !geometryHighlighter) return

    const geom = GeometryUtils.createGeometryFromWkt(
      "POINT(" + Number(info.longitude) + " " + Number(info.latitude) + ")"
    )
    geometryHighlighter.geometryWrapper.qgsGeometry = geom
    geometryHighlighter.geometryWrapper.crs = CoordinateReferenceSystemUtils.wgs84Crs()
  }

  function showMeAndSite() {
    fitYouAndSite(true)
    mainWindow.displayToast("Your location highlighted")
  }

  function setTargetViewMeters(meters) {
    if (isNaN(selectedLat) || isNaN(selectedLon)) return

    const half = Number(meters) / 2.0
    const latDelta = half / 111320.0
    const cosLat = Math.max(0.15, Math.cos(selectedLat * Math.PI / 180.0))
    const lonDelta = half / (111320.0 * cosLat)

    const p1 = GeometryUtils.point(selectedLon - lonDelta, selectedLat - latDelta)
    const p2 = GeometryUtils.point(selectedLon + lonDelta, selectedLat + latDelta)
    const rect = GeometryUtils.createRectangleFromPoints(p1, p2)
    const projected = GeometryUtils.reprojectRectangle(
      rect,
      CoordinateReferenceSystemUtils.wgs84Crs(),
      mapCanvas.mapSettings.destinationCrs
    )

    mapCanvas.mapSettings.setExtent(projected, true)
  }

  function applyViewMode(mode) {
    const value = String(mode)
    if (value === "FIT YOU + SITE") {
      fitYouAndSite(true)
      return
    }
    const n = Number(value.replace(" m", ""))
    if (!isNaN(n)) setTargetViewMeters(n)
  }

  function haversineMeters(lat1, lon1, lat2, lon2) {
    const R = 6371000.0
    const p1 = lat1 * Math.PI / 180.0
    const p2 = lat2 * Math.PI / 180.0
    const dp = (lat2 - lat1) * Math.PI / 180.0
    const dl = (lon2 - lon1) * Math.PI / 180.0
    const a = Math.sin(dp/2) * Math.sin(dp/2) +
              Math.cos(p1) * Math.cos(p2) *
              Math.sin(dl/2) * Math.sin(dl/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c
  }

  function initialBearing(lat1, lon1, lat2, lon2) {
    const p1 = lat1 * Math.PI / 180.0
    const p2 = lat2 * Math.PI / 180.0
    const dl = (lon2 - lon1) * Math.PI / 180.0
    const y = Math.sin(dl) * Math.cos(p2)
    const x = Math.cos(p1) * Math.sin(p2) -
              Math.sin(p1) * Math.cos(p2) * Math.cos(dl)
    return (Math.atan2(y, x) * 180.0 / Math.PI + 360.0) % 360.0
  }

  function cardinal(deg) {
    const names = ["N","NNE","NE","ENE","E","ESE","SE","SSE",
                   "S","SSW","SW","WSW","W","WNW","NW","NNW"]
    return names[Math.round(deg / 22.5) % 16]
  }

  function normalizeDegrees(deg) {
    return (Number(deg) % 360 + 360) % 360
  }

  function currentHeading(info) {
    if (!info) {
      headingSource = "—"
      return NaN
    }

    const speed = info.speedValid ? Number(info.speed) : NaN

    if (info.directionValid && !isNaN(Number(info.direction)) &&
        (!isNaN(speed) && speed >= 0.2222)) {
      headingSource = "movement"
      return normalizeDegrees(info.direction)
    }

    if (info.orientationValid && !isNaN(Number(info.orientation))) {
      headingSource = "compass"
      return normalizeDegrees(info.orientation)
    }

    if (positioning && positioning.orientation !== undefined &&
        !isNaN(Number(positioning.orientation))) {
      headingSource = "compass"
      return normalizeDegrees(positioning.orientation)
    }

    if (info.directionValid && !isNaN(Number(info.direction))) {
      headingSource = "movement"
      return normalizeDegrees(info.direction)
    }

    headingSource = "unavailable"
    return NaN
  }

  function distanceText(meters) {
    const m = Number(meters)
    if (isNaN(m)) return "—"
    if (m < 1000) return (m < 100 ? m.toFixed(1) : m.toFixed(0)) + " m"
    return (m / 1000.0).toFixed(2) + " km"
  }

  function copyCoordinates() {
    if (isNaN(selectedLat) || isNaN(selectedLon)) return
    const s = selectedLat.toFixed(6) + ", " + selectedLon.toFixed(6)
    QFieldUtils.copyTextToClipboard(s)
    mainWindow.displayToast("Coordinates copied")
  }

  function copySiteInfo() {
    if (!selectedSiteId.length) return

    let s = "Trap site " + selectedSiteId +
            " | Q" + selectedQuadrant +
            " | " + selectedStatus +
            " | " + selectedLat.toFixed(6) + ", " + selectedLon.toFixed(6)

    if (selectedDescription.length) s += " | " + selectedDescription

    QFieldUtils.copyTextToClipboard(s)
    mainWindow.displayToast("Trap site info copied")
  }

  function stopNavigation() {
    if (navigation) navigation.clear()
    pointerValid = false
    navigationGuideHidden = false
    mainWindow.displayToast("Navigation stopped")
  }

  function refreshLiveGuidance() {
    if (isNaN(selectedLat) || isNaN(selectedLon)) {
      liveDistance = "—"
      liveBearing = "—"
      liveAccuracy = "—"
      pointerValid = false
      return
    }

    const info = currentGpsInfo()
    if (!info) {
      liveDistance = positioning && positioning.active ? "Waiting for GPS" : "GPS off"
      liveBearing = "—"
      liveAccuracy = "—"
      pointerValid = false
      return
    }

    const d = haversineMeters(Number(info.latitude), Number(info.longitude), selectedLat, selectedLon)
    const b = initialBearing(Number(info.latitude), Number(info.longitude), selectedLat, selectedLon)

    liveDistance = distanceText(d)
    liveBearing = Math.round(b) + "° " + cardinal(b)

    if (info.haccValid && !isNaN(Number(info.hacc))) {
      liveAccuracy = "±" + Number(info.hacc).toFixed(1) + " m"
    } else {
      liveAccuracy = "—"
    }

    const heading = currentHeading(info)
    if (!isNaN(heading)) {
      pointerRotation = normalizeDegrees(b - heading)
      pointerValid = true
    } else {
      pointerRotation = 0
      pointerValid = false
    }
  }

  Rectangle {
    id: navigationPointer
    parent: mainWindow.contentItem
    visible: navigation && navigation.isActive &&
             plugin.selectedSiteId.length > 0 &&
             !plugin.navigationGuideHidden

    anchors.top: parent.top
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.topMargin: 105

    width: Math.min(parent.width * 0.64, 285)
    implicitHeight: pointerLayout.implicitHeight + 18
    radius: 12
    color: Theme.darkGray
    opacity: 0.96
    z: 10000

    ColumnLayout {
      id: pointerLayout
      anchors.fill: parent
      anchors.margins: 9
      spacing: 5

      RowLayout {
        Layout.fillWidth: true
        spacing: 6

        Label {
          Layout.fillWidth: true
          text: "Trap site " + plugin.selectedSiteId + "  •  Q" + plugin.selectedQuadrant
          font.bold: true
          font.pixelSize: 16
          horizontalAlignment: Text.AlignHCenter
        }

        Button {
          text: "HIDE"
          Layout.preferredWidth: 58
          onClicked: plugin.navigationGuideHidden = true
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 10

        Item {
          Layout.preferredWidth: 82
          Layout.preferredHeight: 82

          Item {
            anchors.centerIn: parent
            width: 74
            height: 74
            rotation: plugin.pointerRotation
            opacity: plugin.pointerValid ? 1.0 : 0.35

            Behavior on rotation {
              NumberAnimation { duration: 180; easing.type: Easing.OutQuad }
            }

            Canvas {
              anchors.fill: parent

              onPaint: {
                const ctx = getContext("2d")
                ctx.reset()

                ctx.beginPath()
                ctx.moveTo(width / 2, 2)
                ctx.lineTo(width - 6, height * 0.43)
                ctx.lineTo(width * 0.64, height * 0.43)
                ctx.lineTo(width * 0.64, height - 4)
                ctx.lineTo(width * 0.36, height - 4)
                ctx.lineTo(width * 0.36, height * 0.43)
                ctx.lineTo(6, height * 0.43)
                ctx.closePath()

                ctx.fillStyle = Theme.mainColor
                ctx.fill()
                ctx.lineWidth = 3
                ctx.strokeStyle = "white"
                ctx.stroke()
              }
            }
          }
        }

        ColumnLayout {
          Layout.fillWidth: true
          spacing: 1

          Label {
            text: plugin.liveDistance
            font.bold: true
            font.pixelSize: 26
          }

          Label {
            text: plugin.liveBearing
            font.pixelSize: 15
          }

          Label {
            text: "GPS " + plugin.liveAccuracy
            opacity: 0.8
            font.pixelSize: 13
          }

          Label {
            visible: !plugin.pointerValid
            text: "Heading unavailable"
            opacity: 0.7
            font.pixelSize: 12
          }
        }
      }

      ComboBox {
        Layout.fillWidth: true
        model: plugin.viewOptions
        currentIndex: 0
        onActivated: plugin.applyViewMode(currentText)
      }

      RowLayout {
        Layout.fillWidth: true

        Button {
          Layout.fillWidth: true
          text: "SHOW ME"
          onClicked: plugin.showMeAndSite()
        }

        Button {
          Layout.fillWidth: true
          text: "COPY"
          onClicked: plugin.copyCoordinates()
        }

        Button {
          Layout.fillWidth: true
          text: "STOP"
          onClicked: plugin.stopNavigation()
        }
      }
    }
  }

  Rectangle {
    id: navigationGuideRestore
    parent: mainWindow.contentItem
    visible: navigation && navigation.isActive &&
             plugin.selectedSiteId.length > 0 &&
             plugin.navigationGuideHidden

    anchors.top: parent.top
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.topMargin: 105

    width: Math.min(parent.width * 0.50, 200)
    height: 48
    radius: 12
    color: Theme.darkGray
    opacity: 0.94
    z: 10000

    Button {
      anchors.fill: parent
      text: "GUIDE  •  " + plugin.liveDistance
      onClicked: plugin.navigationGuideHidden = false
    }
  }

  Dialog {
    id: siteListDialog
    parent: mainWindow.contentItem
    modal: true
    visible: false
    title: "All Trap Sites"
    standardButtons: Dialog.Close

    width: Math.min(mainWindow.width * 0.94, 560)
    height: Math.min(mainWindow.height * 0.82, 700)
    x: (mainWindow.width - width) / 2
    y: Math.max(0, (mainWindow.height - height) / 2)

    contentItem: ColumnLayout {
      spacing: 8

      TextField {
        id: siteFilterField
        Layout.fillWidth: true
        placeholderText: "Filter site, quadrant, status, or description"
        onTextChanged: plugin.filterSiteList(text)
      }

      Label {
        text: plugin.filteredSites.length + " trap sites"
        opacity: 0.7
      }

      ScrollView {
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true

        ListView {
          id: siteList
          width: parent.width
          model: plugin.filteredSites
          spacing: 3

          delegate: Button {
            width: siteList.width
            height: 72
            text: plugin.siteListLabel(modelData)
            onClicked: plugin.chooseSiteFromList(modelData)
          }
        }
      }
    }
  }

  Dialog {
    id: fieldQueueDialog
    parent: mainWindow.contentItem
    modal: true
    visible: false
    title: "Trap Site Queue"
    standardButtons: Dialog.Close

    width: Math.min(mainWindow.width * 0.94, 560)
    height: Math.min(mainWindow.height * 0.82, 700)
    x: (mainWindow.width - width) / 2
    y: Math.max(0, (mainWindow.height - height) / 2)

    contentItem: ColumnLayout {
      spacing: 8

      Label {
        text: "Active (not removed) trap sites • nearest first"
        font.bold: true
        wrapMode: Text.Wrap
        Layout.fillWidth: true
      }

      Button {
        Layout.fillWidth: true
        text: "REFRESH DISTANCES"
        onClicked: plugin.buildFieldQueue()
      }

      Label {
        text: plugin.fieldQueueRows.length + " active sites"
        opacity: 0.72
      }

      ScrollView {
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true

        ListView {
          id: queueList
          width: parent.width
          model: plugin.fieldQueueRows
          spacing: 4

          delegate: Button {
            width: queueList.width
            height: 72
            text: plugin.queueLabel(modelData)
            onClicked: plugin.chooseQueueSite(modelData)
          }
        }
      }
    }
  }

  Dialog {
    id: trapDialog
    parent: mainWindow.contentItem
    modal: true
    visible: false
    title: "Trap Finder"
    standardButtons: Dialog.Close

    width: Math.min(mainWindow.width * 0.90, 520)
    height: Math.min(mainWindow.height * 0.86, 720)
    x: (mainWindow.width - width) / 2
    y: Math.max(0, (mainWindow.height - height) / 2)

    contentItem: ScrollView {
      id: trapScroll
      clip: true
      leftPadding: 2
      rightPadding: 10

      ColumnLayout {
        width: Math.max(0, trapScroll.availableWidth)
        spacing: 12

        Label {
          text: "Choose trap site"
          font.bold: true
          font.pixelSize: 20
        }

        RowLayout {
          Layout.fillWidth: true

          TextField {
            id: siteField
            Layout.fillWidth: true
            placeholderText: "Site number (e.g. 1001)"
            inputMethodHints: Qt.ImhDigitsOnly
            onAccepted: plugin.findSite(text)
          }

          Button {
            text: "Find"
            enabled: plugin.catalogReady && !plugin.scanActive
            onClicked: plugin.findSite(siteField.text)
          }
        }

        Button {
          Layout.fillWidth: true
          text: plugin.scanActive ? ("LOADING SITES… " + plugin.scanCount) : "BROWSE ALL TRAP SITES"
          enabled: !plugin.scanActive
          onClicked: plugin.openSiteList()
        }

        RowLayout {
          Layout.fillWidth: true

          Button {
            Layout.fillWidth: true
            text: "CLOSEST SITE"
            enabled: !plugin.scanActive
            onClicked: plugin.loadClosestSite()
          }

          Button {
            Layout.fillWidth: true
            text: "FIELD QUEUE"
            enabled: !plugin.scanActive
            onClicked: plugin.openFieldQueue()
          }
        }

        Button {
          Layout.fillWidth: true
          text: "REFRESH SITE LIST"
          enabled: !plugin.scanActive
          onClicked: plugin.refreshSites()
        }

        Rectangle {
          Layout.fillWidth: true
          height: 1
          color: Theme.mainColor
          opacity: 0.35
        }

        Label {
          visible: plugin.selectedSiteId.length > 0
          text: plugin.selectedDescription.length
                ? ("Trap site " + plugin.selectedSiteId + " — " + plugin.selectedDescription)
                : ("Trap site " + plugin.selectedSiteId)
          font.bold: true
          font.pixelSize: 22
          wrapMode: Text.Wrap
          Layout.fillWidth: true
        }

        GridLayout {
          visible: plugin.selectedSiteId.length > 0
          columns: 2
          columnSpacing: 12
          rowSpacing: 7
          Layout.fillWidth: true

          Label { text: "Quadrant"; font.bold: true }
          Label { text: plugin.selectedQuadrant }

          Label { text: "Trap status"; font.bold: true }
          Label { text: plugin.selectedStatus; wrapMode: Text.Wrap; Layout.fillWidth: true }

          Label { text: "Removed?"; font.bold: true }
          Label { text: plugin.selectedRemoved }

          Label { text: "Latitude"; font.bold: true }
          Label { text: isNaN(plugin.selectedLat) ? "—" : plugin.selectedLat.toFixed(6) }

          Label { text: "Longitude"; font.bold: true }
          Label { text: isNaN(plugin.selectedLon) ? "—" : plugin.selectedLon.toFixed(6) }

          Label { text: "Created"; font.bold: true }
          Label { text: plugin.selectedCreated; wrapMode: Text.Wrap; Layout.fillWidth: true }
        }

        Rectangle {
          visible: plugin.selectedSiteId.length > 0
          Layout.fillWidth: true
          implicitHeight: guidanceColumn.implicitHeight + 22
          radius: 10
          color: Theme.darkGray

          ColumnLayout {
            id: guidanceColumn
            anchors.fill: parent
            anchors.margins: 11
            spacing: 4

            Label {
              text: plugin.liveDistance
              font.bold: true
              font.pixelSize: 34
            }
            Label {
              text: "Bearing: " + plugin.liveBearing
              font.pixelSize: 18
            }
            Label {
              text: "GPS accuracy: " + plugin.liveAccuracy
              opacity: 0.8
            }
          }
        }

        RowLayout {
          visible: plugin.selectedSiteId.length > 0
          Layout.fillWidth: true

          Button {
            Layout.fillWidth: true
            text: "GO TO"
            onClicked: plugin.goToSite()
          }

          Button {
            Layout.fillWidth: true
            text: "NAVIGATE"
            onClicked: plugin.navigateToSite()
          }
        }

        ComboBox {
          visible: plugin.selectedSiteId.length > 0
          Layout.fillWidth: true
          model: plugin.viewOptions
          currentIndex: 0
          onActivated: plugin.applyViewMode(currentText)
        }

        Button {
          visible: plugin.selectedSiteId.length > 0
          Layout.fillWidth: true
          text: "SHOW ME + SITE"
          onClicked: plugin.showMeAndSite()
        }

        RowLayout {
          visible: plugin.selectedSiteId.length > 0
          Layout.fillWidth: true

          Button {
            Layout.fillWidth: true
            text: "COPY COORDS"
            onClicked: plugin.copyCoordinates()
          }

          Button {
            Layout.fillWidth: true
            text: "COPY INFO"
            onClicked: plugin.copySiteInfo()
          }
        }

        Button {
          visible: navigation && navigation.isActive
          Layout.fillWidth: true
          text: "STOP NAVIGATION"
          onClicked: plugin.stopNavigation()
        }

        Label {
          visible: plugin.selectedSiteId.length === 0
          text: plugin.statusText
          wrapMode: Text.Wrap
          Layout.fillWidth: true
          opacity: 0.75
        }

        Label {
          text: "Read-only. Trap Finder does not edit Bait and Trap Sites."
          wrapMode: Text.Wrap
          opacity: 0.65
          font.pixelSize: 12
        }
      }
    }
  }
}
